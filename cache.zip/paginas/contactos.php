<!DOCTYPE html>
<html lang="pt-pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Entre em contacto com o Oasis Dune, alojamento na Praia do Cabedelo, Viana do Castelo.">
    <meta property="og:title" content="Contactos | Oasis Dune">
    <meta property="og:description" content="Entre em contacto com o Oasis Dune, alojamento na Praia do Cabedelo, Viana do Castelo.">
    <meta property="og:type" content="website">
    <link rel="icon" href="../imagens/logo.png">
    <link rel="stylesheet" href="../css/styleconfig.css">
    <link rel="stylesheet" href="../css/styleCont.css">
    <script src="../script/script.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Contactos | Oasis Dune</title>
</head>
<body>
    <div class="fundo-fixo"></div>

    <div class="conteudo-site">
        <header>
            <div class="h-esq">
                <img src="../imagens/logo.png" class='logotipo' height="100px" onclick="goto('index.php')" alt="Oasis Dune – página inicial">
            </div>
            <div class="h-dir">
                <nav class="nav-menu" id="nav-menu">
                    <a href="oalojamento.php">O Alojamento</a> 
                    <a href="experiencias.php">Experiências</a> 
                    <a href="contactos.php">Contactos</a>
                    <a href="calendario.php">Reservar</a>
                </nav>
                <a href="https://www.airbnb.pt/rooms/1193985038143849991?source_impression_id=p3_1792669220_P3AOW4b4XqChBI5x" class="airbnb_btn">Airbnb</a>
                <button class="menu-mobile-btn" id="btn-menu" aria-label="Abrir Menu">
                    
                </button>
            </div>
        </header>

        <div class="titulo">
            <div class="conteudo-titulo">
                <h1>Contactos</h1>
            </div>
        </div>

        <div class="conteudoA">
            <h1>Formas de contacto</h1>
            <div class="areaA">
                <div><i class="fa-solid fa-phone"></i>
                <p>Atendimento 24 horas</p></div>
                <div><i class="fa-solid fa-envelope"></i>
                <p>Lemos frequentemente o email</p></div>
                <div><i class="fa-solid fa-location-dot"></i>
                <p>Estamos disponíveis presencialmente</p></div>
            </div>
        </div>

        <div class="conteudoB">
            <div class="areaB">
                <div class="grega1">
                    <div class="cartinha">
                        <i class="fa-solid fa-phone"></i>
                        <div><h3>Telefone</h3>
                        <p>+351 935 334 117</p></div>
                    </div>
                    <div class="cartinha">
                        <i class="fa-solid fa-envelope"></i>
                        <div><h3>Email</h3>
                        <p>info.oasisdune@gmail.com</p></div>
                    </div>
                    <div class="cartinha">
                        <i class="fa-solid fa-location-dot"></i>
                        <div><h3>Morada</h3>
                        <p>Rua Fernão Martins da Costa, 4935-158 Viana do Castelo</p></div>
                    </div>
                </div>

                <form action="">
                    <h1 class="tituloMsg">Envie-nos uma mensagem</h1>
                    <input type="text" placeholder="Nome" required>
                    <input type="email" placeholder="Email" required>
                    <textarea placeholder="Mensagem" required></textarea>
                    <input type="submit" value="Enviar Mensagem" class="butaomsg">
                </form>
            </div>
        </div>

        <div class="areaReservar">
            <h1>Resolvemos as suas dúvidas? ...</h1>
            <input type="button" value="Reserve agora!" onclick="goto('calendario.php')">
        </div>

        <footer>
            <div>
                <img src="../imagens/logo.png" class='logotipo' height="100px" onclick="goto('index.php')">
                <p>+351 935 334 117</p> 
                <p>info.oasisdune@gmail.com</p> 
                <p>Rua Fernão Martins da Costa, 4935-158 Viana do Castelo</p> 
                <p>Registro nº 159124/AL</p>
            </div>
            <div>
                <b>Sobre o alojamento</b>
                <p>Oasis Dune é uma moradia de luxo junto à Praia do Cabedelo, com acesso direto às dunas e vista para o mar. Ideal para até 6 pessoas, oferece conforto, jacuzzi, terraço, cozinha equipada e espaços de lazer, numa localização perfeita para relaxar e desfrutar de atividades como windsurf, ciclismo e ténis.</p>
            </div>
            <div>
                <h2>Alojamento</h2>
                <a href="oalojamento.php">O Alojamento</a> 
                <a href="experiencias.php">Experiências</a> 
                <a href="contactos.php">Contactos</a>
                <a href="calendario.php">Reservar</a>
                <a href="https://www.livroreclamacoes.pt/" target="_blank" rel="noopener">Livro de Reclamações</a>
                <a href="https://www.airbnb.pt/rooms/1193985038143849991?source_impression_id=p3_1792669220_P3AOW4b4XqChBI5x" class="airbnb_btn">Mais no Airbnb</a>
            </div>
        </footer>
    </div>
</body>
</html>